export type Language = 'ru' | 'en' | 'sr';
export type Role = 'coach' | 'student';
export type Localized = Partial<Record<Language,string>>;
export type Exercise = {
  id:string; workspaceId:string|null; group:string; equipment:string;
  photoUrl:string; videoUrl:string; translations:Record<string,{name:string;description:string;faq:string}>;
};
export type WorkoutItem = { id:string; exerciseId:string; sets:number; reps:number; weight:number; rest:number; };
export type WorkoutTemplate = {id:string;workspaceId:string;title:Localized;items:WorkoutItem[]};
export type SetLog = {setIndex:number;reps:number;weight:number;done:boolean;recordedBy?:string|null};
export type AssignmentItem = WorkoutItem & {logs:SetLog[]};
export type Assignment = {id:string;workspaceId:string;studentId:string;templateId:string|null;title:Localized;date:string;status:'planned'|'active'|'completed'|'skipped';items:AssignmentItem[];note:string;effort:number;pendingVideos?:number};
export type Student = {id:string;name:string; joined:boolean};
export type Membership = {workspaceId:string;workspaceName:string;role:Role;userId:string};
export type Me = {id:string;name:string;language:Language;memberships:Membership[]};
